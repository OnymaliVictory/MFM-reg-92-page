module.exports = function (str) {
  return parseInt(str, 10) || 0
}
