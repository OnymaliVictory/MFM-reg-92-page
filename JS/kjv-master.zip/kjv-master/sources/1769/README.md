Thanks http://www.lord.life/2015/04/04/king-james-bible-1769-av-cpf/
